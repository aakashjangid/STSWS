var assignmentList={
    assignments:[],
    
    addAssignment:function(assignmentText){
        this.assignments.push({
            assignmentText:assignmentText,
            completed:false
        });
    },
    
    deleteAssignment:function(position){
        this.assignments.splice(position,1);
    },
    
    editAssignment:function(position,newAssignmentText){
        this.assignments[position].assignmentText=newAssignmentText;
    },
    
    toggleAssignment:function(position){
        this.assignments[position].completed=!this.assignments[position].completed;
    },
    
    toggleAll:function(){
        var totalAssignments=this.assignments.length;
        var totalCompleted=0;
        for(var j=0;j<totalAssignments;j++){
            if(this.assignments[j].completed===true){
                totalCompleted++;
            }
        }
        
        if(totalAssignments===totalCompleted){
            for(var k=0;k<totalAssignments;k++){
                this.assignments[k].completed=false;
            }
        }
        else{
            for(var x=0;x<totalAssignments;x++){
                this.assignments[x].completed=true;
            }
        }
    }
};

/*

This is the code where we used the eventListener. Now we refactored this code using handlers object.

var displayAssignmentButton=document.getElementById('displayAssignmentButton');
var toggleAssignmentButton=document.getElementById('toggleAssignmentButton');

displayAssignmentButton.addEventListener('click',function(){
   assignmentList.displayAssignment(); 
});

toggleAssignmentButton.addEventListener('click',function(){
    assignmentList.toggleAll();
});
*/

var handlers={    
    toggleAll:function(){
        assignmentList.toggleAll();
        view.displayAssignment();
    },
    
    addAssignment:function(key){
        if(key.keyCode==13){
        var assignmentTextInput=document.getElementById('assignmentTextInput');
        assignmentList.addAssignment(assignmentTextInput.value);
        assignmentTextInput.value='';
        view.displayAssignment();
            }
    },
    
    deleteAssignment:function(i){
        assignmentList.deleteAssignment(i);
        view.displayAssignment();
    },
    
    editAssignment:function(){
        var editAssignmentPostionInput=document.getElementById('editAssignmentPostionInput');
        var editAssignmentTextInput=document.getElementById('editAssignmentTextInput');
        assignmentList.editAssignment(editAssignmentPostionInput.value,editAssignmentTextInput.value);
        editAssignmentPostionInput.value='';
        editAssignmentTextInput.value='';
        view.displayAssignment();
    },
    
    toggleAssignment:function(i){
        assignmentList.toggleAssignment(i);
        view.displayAssignment();
    }
};


var view={
    displayAssignment:function(){
        var assignmentUl=document.querySelector('ul');
        
        var completedCount=0;
        var unCompletedCount=0;
        var totalCount=0;
        
        assignmentUl.innerHTML='';
        for(var i=0;i<assignmentList.assignments.length;i++){
            
            var assignmentLi=document.createElement('li');
            
            var deleteButton=document.createElement('input');
            deleteButton.setAttribute('type', 'button');
            deleteButton.setAttribute('class','deleteButton');
            deleteButton.setAttribute('onclick', 'handlers.deleteAssignment('+i+')');
            
            var toggle=document.createElement('a');
            toggle.setAttribute('href','#');
            toggle.setAttribute('onclick','handlers.toggleAssignment('+i+')');
            
            var toggleButton=document.createElement('IMG');
            
            
            var assignment=assignmentList.assignments[i];
            var assignmentTextwithCompletion='';
            
            if(assignment.completed===true){
                assignmentTextwithCompletion=assignment.assignmentText;
                toggleButton.setAttribute("src", "images/checkbox.png");
                completedCount++;
            }else{
                assignmentTextwithCompletion=assignment.assignmentText;
                toggleButton.setAttribute("src", "images/Unchecked.png");
                unCompletedCount++;
            }
            toggle.appendChild(toggleButton);
            assignmentLi.append(toggle);
            assignmentLi.append(assignmentTextwithCompletion);
            assignmentLi.appendChild(deleteButton);
            assignmentUl.appendChild(assignmentLi);
            totalCount=i+1;
        }
       
        var count=document.querySelector('article');
        count.innerHTML='';
        var p=document.createElement('p');
        p.textContent='Total '+totalCount+' Completed '+completedCount+ ' Uncompleted ' +unCompletedCount;
        count.appendChild(p);
    }
};