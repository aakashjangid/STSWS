var assignmentList={
    assignments:[],
    
    addAssignment:function(assignmentText){
        this.assignments.push({
            assignmentText:assignmentText,
            completed:false
        });
    },
    
    deleteAssignment:function(position){
        this.assignments.splice(position,1);
    },
    
    editAssignment:function(position,newAssignmentText){
        this.assignments[position].assignmentText=newAssignmentText;
    },
    
    toggleAssignment:function(position){
        this.assignments[position].completed=!this.assignments[position].completed;
    },
    
    toggleAll:function(){
        var totalAssignments=this.assignments.length;
        var totalCompleted=0;
        for(var j=0;j<totalAssignments;j++){
            if(this.assignments[j].completed===true){
                totalCompleted++;
            }
        }
        
        if(totalAssignments===totalCompleted){
            for(var k=0;k<totalAssignments;k++){
                this.assignments[k].completed=false;
            }
        }
        else{
            for(var x=0;x<totalAssignments;x++){
                this.assignments[x].completed=true;
            }
        }
    }
};

/*

This is the code where we used the eventListener. Now we refactored this code using handlers object.

var displayAssignmentButton=document.getElementById('displayAssignmentButton');
var toggleAssignmentButton=document.getElementById('toggleAssignmentButton');

displayAssignmentButton.addEventListener('click',function(){
   assignmentList.displayAssignment(); 
});

toggleAssignmentButton.addEventListener('click',function(){
    assignmentList.toggleAll();
});
*/

var handlers={    
    toggleAll:function(){
        assignmentList.toggleAll();
        view.displayAssignment();
    },
    
    addAssignment:function(){
        var assignmentTextInput=document.getElementById('assignmentTextInput');
        assignmentList.addAssignment(assignmentTextInput.value);
        assignmentTextInput.value='';
        view.displayAssignment();
    },
    
    deleteAssignment:function(){
        var deleteAssignmentPositionInput=document.getElementById('deleteAssignmentPositionInput');
        assignmentList.deleteAssignment(deleteAssignmentPositionInput.value);
        deleteAssignmentPositionInput.value='';
        view.displayAssignment();
    },
    
    editAssignment:function(){
        var editAssignmentPostionInput=document.getElementById('editAssignmentPostionInput');
        var editAssignmentTextInput=document.getElementById('editAssignmentTextInput');
        assignmentList.editAssignment(editAssignmentPostionInput.value,editAssignmentTextInput.value);
        editAssignmentPostionInput.value='';
        editAssignmentTextInput.value='';
        view.displayAssignment();
    },
    
    toggleAssignment:function(){
        var toggleAssignmentPostionInput=document.getElementById('toggleAssignmentPostionInput');
        assignmentList.toggleAssignment(toggleAssignmentPostionInput.value);
        toggleAssignmentPostionInput.value='';
        view.displayAssignment();
    }
};


var view={
    displayAssignment:function(){
        var assignmentUl=document.querySelector('ul');
        assignmentUl.innerHTML='';
        for(var i=0;i<assignmentList.assignments.length;i++){
            var assignmentLi=document.createElement('li');
            var deleteButton=document.createElement('button');
            deleteButton.setAttribute('value',i);
            deleteButton.setAttribute('onclick','handlers.deleteAssignment()');
            
            var assignment=assignmentList.assignments[i];
            var assignmentTextwithCompletion='';
            if(assignment.completed===true){
                assignmentTextwithCompletion=' (X) '+assignment.assignmentText;
            }else{
                assignmentTextwithCompletion=' ( ) '+assignment.assignmentText;
            }
            assignmentLi.textContent=assignmentTextwithCompletion;
            assignmentLi.appendChild(deleteButton);
            assignmentUl.appendChild(assignmentLi);
        }
    }
};