package com.wastedpotential.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wastedpotential.model.Employee;
import com.wastedpotential.model.Title;
import com.wastedpotential.service.TitleService;
import com.wastedpotential.serviceimpl.TitleServiceImpl;

@WebServlet("/AddTitleController")
public class AddTitleController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private TitleService titleService;

	public AddTitleController() {
		super();
		titleService = new TitleServiceImpl();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String titleValue = request.getParameter("title");
		String title_start_date = request.getParameter("title_start_date");
		String title_end_date = request.getParameter("title_end_date");
		Employee employee = (Employee) request.getAttribute("employee");

		Title title = new Title();
		title.setTitle(titleValue);
		title.setFrom_date(Date.valueOf(title_start_date));
		title.setTo_date(Date.valueOf(title_end_date));
		title.setEmp_no(employee.getEmp_no());

		boolean success = titleService.insertTitle(title);
		if (success) {
			request.setAttribute("message", "Employee Added Successfully");
			getServletContext().getRequestDispatcher("/AddDepartmentController").forward(request, response);
		} else {
			request.setAttribute("message", "Unable to Add Employment Details");
			getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}

}