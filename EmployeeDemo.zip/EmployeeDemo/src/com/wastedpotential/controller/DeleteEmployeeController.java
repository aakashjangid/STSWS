package com.wastedpotential.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wastedpotential.service.EmployeeService;
import com.wastedpotential.serviceimpl.EmployeeServiceImpl;

@WebServlet("/DeleteEmployeeController")
public class DeleteEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService employeeService;
       
    public DeleteEmployeeController() {
        super();
        employeeService = new EmployeeServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer id = Integer.parseInt(request.getParameter("id"));
		boolean success = employeeService.deleteEmployee(id);
		if(success) {
			getServletContext().getRequestDispatcher("/ListEmployeesController?success=cdelete").forward(request, response);
		}else {
			getServletContext().getRequestDispatcher("/ListEmployeesController?err=nodelete").forward(request, response);
		}
			
	}

}