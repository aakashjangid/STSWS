package com.wastedpotential.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wastedpotential.model.DeptEmployee;
import com.wastedpotential.model.Employee;
import com.wastedpotential.service.DepartmentService;
import com.wastedpotential.serviceimpl.DepartmentServiceImpl;

@WebServlet("/AddDepartmentController")
public class AddDepartmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DepartmentService departmentService;
	
    public AddDepartmentController() {
        super();
        departmentService = new DepartmentServiceImpl();
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String dept = request.getParameter("dept_name");
		String dept_start_date = request.getParameter("dept_start_date");
		String dept_end_date = request.getParameter("dept_end_date");
		Employee employee = (Employee) request.getAttribute("employee");
		
		int deptNo = departmentService.getDepartmentNumber(dept);
		
		DeptEmployee deptEmployee = new DeptEmployee();
		deptEmployee.setEmp_no(employee.getEmp_no());
		deptEmployee.setFrom_date(Date.valueOf(dept_start_date));
		deptEmployee.setTo_date(Date.valueOf(dept_end_date));
		deptEmployee.setDept_no(deptNo);
		
		boolean success = departmentService.insertDepartment(deptEmployee);
		if(success) {
			request.setAttribute("message", "Employee Added Successfully");
			getServletContext().getRequestDispatcher("/ListEmployeesController").forward(request, response);
		} else {
			request.setAttribute("message", "Unable to Add Department Details");
			getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		}
    }

}