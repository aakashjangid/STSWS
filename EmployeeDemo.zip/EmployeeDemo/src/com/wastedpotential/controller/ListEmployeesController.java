package com.wastedpotential.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wastedpotential.model.Employee;
import com.wastedpotential.service.EmployeeService;
import com.wastedpotential.serviceimpl.EmployeeServiceImpl;

@WebServlet("/ListEmployeesController")
public class ListEmployeesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private EmployeeService employeeService = null;
   
    public ListEmployeesController() {
        super();
       employeeService = new EmployeeServiceImpl();
    }
    
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	List<Employee> employees = employeeService.getAllEmployees(); 
		req.setAttribute("employees", employees);
		getServletContext().getRequestDispatcher("/listEmployees.jsp").forward(req, resp);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Employee> employees = employeeService.getAllEmployees(); 
		request.setAttribute("employees", employees);
		getServletContext().getRequestDispatcher("/listEmployees.jsp?msg=success").forward(request, response);
	}

}