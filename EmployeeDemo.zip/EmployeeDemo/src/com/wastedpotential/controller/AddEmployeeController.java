package com.wastedpotential.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wastedpotential.model.Employee;
import com.wastedpotential.service.EmployeeService;
import com.wastedpotential.serviceimpl.EmployeeServiceImpl;

@WebServlet("/AddEmployeeController")
public class AddEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private EmployeeService employeeService;
    
    public AddEmployeeController() {
        super();
        employeeService = new EmployeeServiceImpl();
    }
    
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	getServletContext().getRequestDispatcher("/addEmployee.jsp").forward(req, resp);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String first_name = request.getParameter("first_name");
		String last_name = request.getParameter("last_name");
		String hire_date = request.getParameter("hire_date");
		String birth_date = request.getParameter("birth_date");
		
		Employee employee = new Employee();
		employee.setFirst_name(first_name);
		employee.setLast_name(last_name);
		employee.setBirth_date(Date.valueOf(birth_date));
		employee.setHire_date(Date.valueOf(hire_date));
		
		boolean success = employeeService.insert(employee);
		if(success) {
			Employee addedEmployee = employeeService.getRecentAddedEmployee();
			request.setAttribute("employee", addedEmployee);
			getServletContext().getRequestDispatcher("/AddSalaryController").forward(request, response);
		}else {
			request.setAttribute("message", "Unable to Add Employee");
			getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}

}