package com.wastedpotential.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wastedpotential.model.Employee;
import com.wastedpotential.model.Salary;
import com.wastedpotential.service.SalaryService;
import com.wastedpotential.serviceimpl.SalaryServiceImpl;

@WebServlet("/AddSalaryController")
public class AddSalaryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private SalaryService salaryService;
    
    public AddSalaryController() {
        super();
        salaryService = new SalaryServiceImpl();
    }

  
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	List<Salary> salaries = salaryService.getAllSalaries();
    	req.setAttribute("salaries", salaries);
    	getServletContext().getRequestDispatcher("/listSalaries.jsp").forward(req, resp);
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int salaryAmount = Integer.parseInt(request.getParameter("salary"));
		String fromDate = request.getParameter("start_date");
		String endDate = request.getParameter("end_date");
		Employee employee = (Employee) request.getAttribute("employee");
		
		Salary salary = new Salary();
		salary.setSalary(salaryAmount);
		salary.setFrom_date(Date.valueOf(fromDate));
		salary.setTo_date(Date.valueOf(endDate));
		salary.setEmp_no(employee.getEmp_no());
		
		boolean success = salaryService.insertSalary(salary);
		if(success) {
		request.setAttribute("message", "Employee Added Successfully");
		getServletContext().getRequestDispatcher("/AddTitleController").forward(request, response);
		}else {
			request.setAttribute("message", "Unable to Add Salary");
			getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}

}