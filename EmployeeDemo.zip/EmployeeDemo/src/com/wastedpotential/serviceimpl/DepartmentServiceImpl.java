package com.wastedpotential.serviceimpl;

import com.wastedpotential.dao.DepartmentDAO;
import com.wastedpotential.daoimpl.DepartmentDAOImpl;
import com.wastedpotential.model.DeptEmployee;
import com.wastedpotential.service.DepartmentService;

public class DepartmentServiceImpl implements DepartmentService {

	private DepartmentDAO departmentDAO;
	
	public DepartmentServiceImpl() {
		departmentDAO = new DepartmentDAOImpl();
	}
	
	@Override
	public boolean insertDepartment(DeptEmployee deptEmployee) {
		return departmentDAO.insertDepartment(deptEmployee);
	}

	@Override
	public int getDepartmentNumber(String dept) {
		return departmentDAO.getDepartmentNumber(dept);
	}

}