package com.wastedpotential.serviceimpl;

import java.util.List;

import com.wastedpotential.dao.EmployeeDAO;
import com.wastedpotential.daoimpl.EmployeeDAOImpl;
import com.wastedpotential.model.Employee;
import com.wastedpotential.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDAO employeeDAO;
	
	public EmployeeServiceImpl() {
		employeeDAO = new EmployeeDAOImpl();
	}
	
	@Override
	public boolean insert(Employee employee) {
		return employeeDAO.insert(employee);
	}

	@Override
	public Employee getRecentAddedEmployee() {
		return employeeDAO.getRecentAddedEmployee();
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeDAO.getAllEmployees();
	}

	@Override
	public boolean deleteEmployee(Integer id) {
		return employeeDAO.deleteEmployee(id);
	}

}