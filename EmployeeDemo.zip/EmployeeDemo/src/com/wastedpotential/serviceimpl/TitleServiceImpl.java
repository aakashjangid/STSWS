package com.wastedpotential.serviceimpl;

import com.wastedpotential.dao.TitleDAO;
import com.wastedpotential.daoimpl.TitleDAOImpl;
import com.wastedpotential.model.Title;
import com.wastedpotential.service.TitleService;

public class TitleServiceImpl implements TitleService {
	
	private TitleDAO titleDAO;
	
	public TitleServiceImpl() {
		titleDAO = new TitleDAOImpl();
	}

	@Override
	public boolean insertTitle(Title title) {
		return titleDAO.insertTitle(title);
	}

}