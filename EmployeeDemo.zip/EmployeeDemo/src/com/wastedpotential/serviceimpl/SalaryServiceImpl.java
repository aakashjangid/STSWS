package com.wastedpotential.serviceimpl;

import java.util.List;

import com.wastedpotential.dao.SalaryDAO;
import com.wastedpotential.daoimpl.SalaryDAOImpl;
import com.wastedpotential.model.Salary;
import com.wastedpotential.service.SalaryService;

public class SalaryServiceImpl implements SalaryService {
	
	private SalaryDAO salaryDAO;
	
	public SalaryServiceImpl() {
		salaryDAO = new SalaryDAOImpl();
	}

	@Override
	public boolean insertSalary(Salary salary) {
		return salaryDAO.insert(salary);
	}

	@Override
	public List<Salary> getAllSalaries() {
		return salaryDAO.getAllSalaries();
	}

}
