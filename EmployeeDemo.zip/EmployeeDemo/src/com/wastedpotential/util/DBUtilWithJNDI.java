package com.wastedpotential.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * This is the DBUtil class which will load the driver class. Also it will
 * return the Connection Object.
 * @author aakash.jangid
 */
public class DBUtilWithJNDI {

	/**
	 * This is the Connection reference which will help us to fire query to database.
	 */
	private static Connection connection;

	/**
	 * This is the Prepared Statement reference
	 */
	public static PreparedStatement pstmt;

	/**
	 * @return This method will return the connection object whenever this method is called
	 */
	private static Connection getConnection() {
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/mydb");
			connection = ds.getConnection();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	/**
	 * @return This method will return the Prepared Statement object whenever this
	 *         method is called
	 */
	public static PreparedStatement createStatment(String sql) {
		try {
			pstmt = getConnection().prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pstmt;
	}
}