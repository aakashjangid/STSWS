package com.wastedpotential.model;

public class Department {

	private Character dept_no;
	private String dept_name;
	
	public Department() {
	}
	
	public Department(Character dept_no, String dept_name) {
		super();
		this.dept_no = dept_no;
		this.dept_name = dept_name;
	}

	public Character getDept_no() {
		return dept_no;
	}
	public void setDept_no(Character dept_no) {
		this.dept_no = dept_no;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}	
}