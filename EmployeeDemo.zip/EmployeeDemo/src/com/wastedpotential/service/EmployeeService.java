package com.wastedpotential.service;

import java.util.List;

import com.wastedpotential.model.Employee;

public interface EmployeeService {

	public boolean insert(Employee employee);

	public Employee getRecentAddedEmployee();

	public List<Employee> getAllEmployees();

	public boolean deleteEmployee(Integer id);
	
}
