package com.wastedpotential.service;

import java.util.List;

import com.wastedpotential.model.Salary;

public interface SalaryService {

	public boolean insertSalary(Salary salary);

	public List<Salary> getAllSalaries();
	
}
