package com.wastedpotential.service;

import com.wastedpotential.model.Title;

public interface TitleService {

	public boolean insertTitle(Title title);
	
}
