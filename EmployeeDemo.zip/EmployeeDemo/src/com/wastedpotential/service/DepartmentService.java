package com.wastedpotential.service;

import com.wastedpotential.model.DeptEmployee;

public interface DepartmentService {

	public boolean insertDepartment(DeptEmployee deptEmployee);

	public int getDepartmentNumber(String dept);
	
}
