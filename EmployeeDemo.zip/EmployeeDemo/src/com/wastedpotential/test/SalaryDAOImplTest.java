package com.wastedpotential.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.wastedpotential.dao.SalaryDAO;
import com.wastedpotential.daoimpl.SalaryDAOImpl;
import com.wastedpotential.model.Salary;

public class SalaryDAOImplTest {

	private SalaryDAO salaryDAO;
	
	@Before
	public void setUp() {
		salaryDAO = new SalaryDAOImpl();
	}
	
	@Test
	public void testInsert_whenPassed_salaryObject() {
		Salary salary = new Salary(5000,Date.valueOf("2018-04-16"), Date.valueOf("2018-04-20"),35);
		boolean result = salaryDAO.insert(salary);
		assertEquals(true, result);
	}
	
	@Test(expected=NullPointerException.class)
	public void testInsert_whenPassed_null() {
		boolean result = salaryDAO.insert(null);
		assertEquals(false, result);
	}
	
	@Test
	public void testInsert_whenPassed_emptySalaryObject() {
		Salary salary = new Salary();
		boolean result = salaryDAO.insert(salary);
		assertEquals(false, result);
	}

	@Test
	public void testGetAllSalaries() {
		Salary salary = new Salary(5000,Date.valueOf("2018-04-16"), Date.valueOf("2018-04-20"),35);
		salaryDAO.insert(salary);
		List<Salary> salaries = salaryDAO.getAllSalaries();
		assertFalse(salaries.isEmpty());
	}

}
