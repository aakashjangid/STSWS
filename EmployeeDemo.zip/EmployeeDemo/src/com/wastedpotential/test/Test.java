package com.wastedpotential.test;

import com.wastedpotential.model.Employee;
import com.wastedpotential.service.EmployeeService;
import com.wastedpotential.serviceimpl.EmployeeServiceImpl;

public class Test {

	public static void main(String[] args) {
		
		EmployeeService service = new EmployeeServiceImpl();
		Employee employee = service.getRecentAddedEmployee();
		System.out.println(employee.getEmp_no()+" "+employee.getFirst_name()+" "+employee.getLast_name());
	}
	
}