package com.wastedpotential.test;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.Before;
import org.junit.Test;

import com.wastedpotential.dao.TitleDAO;
import com.wastedpotential.daoimpl.TitleDAOImpl;
import com.wastedpotential.model.Title;

public class TitleDAOImplTest {
	
	private TitleDAO titleDAO;
	
	@Before
	public void setUp() {
		titleDAO = new TitleDAOImpl();
	}

	@Test
	public void testInsertTitle_whenPassed_titleObject() {
		Title title = new Title("Test", Date.valueOf("2018-05-15"), Date.valueOf("2018-05-03") , 35);
		boolean result = titleDAO.insertTitle(title);
		assertEquals(true, result);
	}
	
	@Test(expected=NullPointerException.class)
	public void testInsertTitle_whenPassed_null() {
		boolean result = titleDAO.insertTitle(null);
		assertEquals(false, result);
	}
	
	@Test
	public void testInsertTitle_whenPassed_emptyTitleObject() {
		Title title = new Title();
		boolean result = titleDAO.insertTitle(title);
		assertEquals(false, result);
	}

}
