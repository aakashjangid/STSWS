package com.wastedpotential.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.sql.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.wastedpotential.dao.EmployeeDAO;
import com.wastedpotential.daoimpl.EmployeeDAOImpl;
import com.wastedpotential.model.Employee;

public class EmployeeDAOTest {
	
	private EmployeeDAO employeeDAO;
	
	@Before
	public void setUp() {
		employeeDAO = new EmployeeDAOImpl();
	}

	@Test
	public void testInsert_whenPassed_AnEmployeeObject() {
		Employee employee = new Employee(1,"Test","1",Date.valueOf("2018-04-12"),Date.valueOf("2018-04-15"), "M");
		boolean result = employeeDAO.insert(employee);
		assertEquals(true, result);
	}
	
	@Test(expected=NullPointerException.class)
	public void testInsert_whenPassed_Null() {
		boolean result = employeeDAO.insert(null);
		assertEquals(false, result);
	}
	
	@Test
	public void testInsert_whenPassed_EmptyEmployeeObject() {
		Employee employee = new Employee();
		boolean result = employeeDAO.insert(employee);
		assertEquals(false, result);
	}

	@Test
	public void testGetRecentAddedEmployee() {
		Employee employee = new Employee("Test","1",Date.valueOf("2018-04-12"),Date.valueOf("2018-04-15"), "M");
		employeeDAO.insert(employee);
		Employee recentEmployee = employeeDAO.getRecentAddedEmployee();
		assertEquals(employee.getFirst_name(), recentEmployee.getFirst_name());
	}

	@Test
	public void testGetAllEmployees() {
		Employee employee = new Employee("Test","1",Date.valueOf("2018-04-12"),Date.valueOf("2018-04-15"), "M");
		employeeDAO.insert(employee);
		List<Employee> employees = employeeDAO.getAllEmployees();
		assertFalse(employees.isEmpty());
	}
	
	@Test
	public void testGetAllEmployees_WhetherLastEmployeeIsInList() {
		Employee employee = new Employee("Test","1",Date.valueOf("2018-04-12"),Date.valueOf("2018-04-15"), "M");
		employeeDAO.insert(employee);
		Employee recentEmployee = employeeDAO.getRecentAddedEmployee();
		List<Employee> employees = employeeDAO.getAllEmployees();
		int position = employees.size()-1;
		Employee lastEmployee = employees.get(position);
		assertEquals(recentEmployee.getEmp_no(), lastEmployee.getEmp_no());
	}

}