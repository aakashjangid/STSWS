package com.wastedpotential.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.sql.Date;

import org.junit.Before;
import org.junit.Test;

import com.wastedpotential.dao.DepartmentDAO;
import com.wastedpotential.daoimpl.DepartmentDAOImpl;
import com.wastedpotential.model.DeptEmployee;

public class DepartmentDAOImplTest {
	
	private DepartmentDAO departmentDAO;
	
	@Before
	public void setUp() {
		departmentDAO = new DepartmentDAOImpl();
	}

	@Test
	public void testInsertDepartment_whenPassed_deptEmployeeObject() {
		DeptEmployee deptEmployee = new DeptEmployee(Date.valueOf("2018-04-15"), Date.valueOf("2018-05-15"), 35, 1); 
		boolean result = departmentDAO.insertDepartment(deptEmployee);
		assertTrue(result);
	}
	
	@Test(expected=AssertionError.class)
	public void testInsertDepartment_whenPassed_null() { 
		boolean result = departmentDAO.insertDepartment(null);
		assertTrue(result);
	}
	
	@Test
	public void testInsertDepartment_whenPassed_emptyDeptEmployeeObject() {
		DeptEmployee deptEmployee = new DeptEmployee(); 
		boolean result = departmentDAO.insertDepartment(deptEmployee);
		assertEquals(false,result);
	}

	@Test
	public void testGetDepartmentNumber_whenPassed_correctDeptName() {
		int deptNo = departmentDAO.getDepartmentNumber("Training");
		assertEquals(1, deptNo);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetDepartmentNumber_whenPassed_null() {
		int deptNo = departmentDAO.getDepartmentNumber(null);
		assertEquals(1, deptNo);
	}
	
	@Test
	public void testGetDepartmentNumber_whenPassed_emptyString() {
		int deptNo = departmentDAO.getDepartmentNumber("");
		assertEquals(0, deptNo);
	}

}