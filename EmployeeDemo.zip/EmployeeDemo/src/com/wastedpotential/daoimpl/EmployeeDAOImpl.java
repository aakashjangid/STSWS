package com.wastedpotential.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wastedpotential.dao.EmployeeDAO;
import com.wastedpotential.model.Employee;
import com.wastedpotential.util.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean insert(Employee employee) {
		String sql = "INSERT INTO employees(first_name, last_name, birth_date, hire_date, gender) VALUES(?,?,?,?,?)";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			pstmt.setString(1, employee.getFirst_name());
			pstmt.setString(2, employee.getLast_name());
			pstmt.setDate(3, employee.getBirth_date());
			pstmt.setDate(4, employee.getHire_date());
			pstmt.setString(5, employee.getGender());
			pstmt.executeUpdate();
			pstmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Employee getRecentAddedEmployee() {
		Employee employee = null;
		String sql = "SELECT * FROM employees ORDER BY emp_no DESC LIMIT 1";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				employee = new Employee();
				employee.setEmp_no(rs.getInt("emp_no"));
				employee.setFirst_name(rs.getString("first_name"));
				employee.setLast_name(rs.getString("last_name"));
				employee.setBirth_date(rs.getDate("birth_date"));
				employee.setHire_date(rs.getDate("hire_date"));
				employee.setGender(rs.getString("gender"));
			}
			rs.close();
			pstmt.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employees = new ArrayList<>();
		Employee employee = null;
		String sql = "SELECT * FROM employees";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				employee = new Employee();
				employee.setEmp_no(rs.getInt("emp_no"));
				employee.setFirst_name(rs.getString("first_name"));
				employee.setLast_name(rs.getString("last_name"));
				employee.setBirth_date(rs.getDate("birth_date"));
				employee.setHire_date(rs.getDate("hire_date"));
				employee.setGender(rs.getString("gender"));
				employees.add(employee);
			}
			rs.close();
			pstmt.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return employees;
	}

	@Override
	public boolean deleteEmployee(Integer id) {
		String sql = "DELETE FROM employees WHERE emp_no=?";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			pstmt.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}