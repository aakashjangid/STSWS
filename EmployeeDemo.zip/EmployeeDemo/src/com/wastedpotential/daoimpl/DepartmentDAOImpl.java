package com.wastedpotential.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.wastedpotential.dao.DepartmentDAO;
import com.wastedpotential.model.DeptEmployee;
import com.wastedpotential.util.DBUtil;

public class DepartmentDAOImpl implements DepartmentDAO {

	@Override
	public boolean insertDepartment(DeptEmployee deptEmployee) {
		String sql = "INSERT INTO dept_emp(emp_no, dept_no, from_date, to_date) VALUES(?,?,?,?)";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			pstmt.setInt(1, deptEmployee.getEmp_no());
			pstmt.setInt(2, deptEmployee.getDept_no());
			pstmt.setDate(3, deptEmployee.getFrom_date());
			pstmt.setDate(4, deptEmployee.getTo_date());
			pstmt.executeUpdate();
			pstmt.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public int getDepartmentNumber(String dept) {
		int deptNo = 0;
		String sql = "SELECT * FROM departments WHERE dept_name=?";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			pstmt.setString(1, dept);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				deptNo = rs.getInt("dept_no");
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return deptNo;
	}

}