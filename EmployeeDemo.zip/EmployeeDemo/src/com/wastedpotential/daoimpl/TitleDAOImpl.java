package com.wastedpotential.daoimpl;

import java.sql.PreparedStatement;

import com.wastedpotential.dao.TitleDAO;
import com.wastedpotential.model.Title;
import com.wastedpotential.util.DBUtil;

public class TitleDAOImpl implements TitleDAO {

	@Override
	public boolean insertTitle(Title title) {
		String sql = "INSERT INTO titles(title, from_date, to_date, emp_no) VALUES(?,?,?,?)";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			pstmt.setString(1, title.getTitle());
			pstmt.setDate(2, title.getFrom_date());
			pstmt.setDate(3, title.getTo_date());
			pstmt.setInt(4, title.getEmp_no());
			pstmt.executeUpdate();
			pstmt.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}