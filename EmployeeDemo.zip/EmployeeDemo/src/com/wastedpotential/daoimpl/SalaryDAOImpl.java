package com.wastedpotential.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wastedpotential.dao.SalaryDAO;
import com.wastedpotential.model.Salary;
import com.wastedpotential.util.DBUtil;

public class SalaryDAOImpl implements SalaryDAO {

	@Override
	public boolean insert(Salary salary) {
		String sql = "INSERT INTO salaries(salary, from_date, to_date, emp_no) VALUES(?,?,?,?)";
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			pstmt.setInt(1, salary.getSalary());
			pstmt.setDate(2, salary.getFrom_date());
			pstmt.setDate(3, salary.getTo_date());
			pstmt.setInt(4, salary.getEmp_no());
			pstmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Salary> getAllSalaries() {
		List<Salary> salaries = new ArrayList<>();
		String sql = "SELECT * FROM salaries";
		Salary salary = null;
		try {
			PreparedStatement pstmt = DBUtil.createStatment(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				salary = new Salary();
				salary.setEmp_no(rs.getInt("emp_no"));
				salary.setSalary(rs.getInt("salary"));
				salary.setFrom_date(rs.getDate("from_date"));
				salary.setTo_date(rs.getDate("to_date"));
				salaries.add(salary);
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return salaries;
	}

}