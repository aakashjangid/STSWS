package com.wastedpotential.dao;

import java.util.List;

import com.wastedpotential.model.Employee;

public interface EmployeeDAO {

	public boolean insert(Employee employee);

	public Employee getRecentAddedEmployee();

	public List<Employee> getAllEmployees();

	public boolean deleteEmployee(Integer id);
	
}