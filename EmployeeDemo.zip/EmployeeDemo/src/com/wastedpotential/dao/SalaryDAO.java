package com.wastedpotential.dao;

import java.util.List;

import com.wastedpotential.model.Salary;

public interface SalaryDAO {

	boolean insert(Salary salary);

	List<Salary> getAllSalaries();
	
}
