package com.wastedpotential.dao;

import com.wastedpotential.model.Title;

public interface TitleDAO {

	public boolean insertTitle(Title title);
	
}