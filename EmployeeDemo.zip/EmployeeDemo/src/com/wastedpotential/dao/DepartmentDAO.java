package com.wastedpotential.dao;

import com.wastedpotential.model.DeptEmployee;

public interface DepartmentDAO {

	public boolean insertDepartment(DeptEmployee deptEmployee);

	public int getDepartmentNumber(String dept);
	
}