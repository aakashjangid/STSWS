function getText() {
			var nameText = document.getElementById('nameText').value;
			var contactText = document.getElementById('contactText').value;
			var space = " , ";
			if (nameText != "" && contactText.length >= 3) {

				var suggestion = nameText.concat(contactText[0],
						contactText[1], contactText[2], space);
				var suggestion2 = nameText.concat(
						contactText[contactText.length - 1],
						contactText[contactText.length - 2],
						contactText[contactText.length - 3], space);
				var suggestion3 = nameText.concat(
						contactText[contactText.length - 3],
						contactText[contactText.length - 2],
						contactText[contactText.length - 1]);
				document.getElementById("help").innerHTML = "Suggestions - "
						+ suggestion + suggestion2 + suggestion3;
			}
		}
		
function passwordAlert() {
	alert("Password must contain minimum 8 characters and no special characters are allowed");
};