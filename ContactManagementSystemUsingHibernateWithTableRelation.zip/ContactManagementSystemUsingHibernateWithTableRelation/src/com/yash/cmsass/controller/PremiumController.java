package com.yash.cmsass.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cmsass.model.User;
import com.yash.cmsass.service.UserService;
import com.yash.cmsass.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class PremiumController
 */
@WebServlet("/PremiumController")
public class PremiumController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService service;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PremiumController() {
		service = new UserServiceImpl();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");

		String premiumOption = request.getParameter("premiumOption");
		boolean check = service.updateToPremium(user, premiumOption);
		if(check) {
			HttpSession session = request.getSession(false);
			System.out.println("Logged Out - " + session.getAttribute("username"));
			session.invalidate();
			response.sendRedirect("./home.jsp?msg=Request for Premium has been Sent! Please Login Again");
		}else {
			response.sendRedirect("./home.jsp?err=Something Went Wrong! Please Try Again");
		}
	}
}