package com.yash.cmsass.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmsass.model.Contact;
import com.yash.cmsass.service.ContactService;
import com.yash.cmsass.service.UserService;
import com.yash.cmsass.serviceimpl.ContactServiceImpl;
import com.yash.cmsass.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class SendSms
 */
@WebServlet("/SendSms")
public class SendSms extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService service;
	private ContactService contactService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendSms() {
        service= new UserServiceImpl();
        contactService=new ContactServiceImpl();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	Contact contact = contactService.getContact(id);
		request.setAttribute("contact", contact);
		getServletContext().getRequestDispatcher("/sendSms.jsp").forward(request, response);
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String number = request.getParameter("receiverNumber");
		String message = request.getParameter("message");
		System.out.println(number+" , "+message);
		
		boolean check = service.sendSms(number,message);
		if(check){
			response.sendRedirect("./FirstPageWelcome.jsp?msg=SMS Sent Successfully");
		}else {
			response.sendRedirect("./FirstPageWelcome.jsp?err=Unable to send SMS");
		}
	}
}