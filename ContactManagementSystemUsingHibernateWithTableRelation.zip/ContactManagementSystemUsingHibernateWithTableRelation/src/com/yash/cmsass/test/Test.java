package com.yash.cmsass.test;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import com.yash.cmsass.model.Contact;
import com.yash.cmsass.model.User;
import com.yash.hibernate.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.openSession();
		session.beginTransaction();
		
		
		
		User user = new User();
		user.setName("Test");
		user.setContact("Test");
		user.setAddress("Test");
		user.setLoginname("Test");
		user.setEmail("Test");
		user.setPassword("Test");
		
		Contact contact = new Contact();
		contact.setName("Test");
		contact.setContact("Test");
		contact.setAddress("Test");
		contact.setUser(user);
		
		List<Contact> contacts = new ArrayList<Contact>();
		contacts.add(contact);
		user.setContacts(contacts);
		session.save(user);
		session.save(contact);
	
		session.getTransaction().commit();
		session.close();
	}

}
